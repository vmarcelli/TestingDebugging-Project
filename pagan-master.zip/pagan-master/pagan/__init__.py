from .pagan import Avatar

MD5 = pagan.generator.HASH_MD5
SHA1 = pagan.generator.HASH_SHA1
SHA224 = pagan.generator.HASH_SHA224
SHA256 = pagan.generator.HASH_SHA256
SHA384 = pagan.generator.HASH_SHA384
SHA512 = pagan.generator.HASH_SHA512