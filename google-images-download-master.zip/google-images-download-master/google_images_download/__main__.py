#!/usr/bin/env python
from __future__ import absolute_import

from .__init__ import main

if __name__ == '__main__':
    main()
