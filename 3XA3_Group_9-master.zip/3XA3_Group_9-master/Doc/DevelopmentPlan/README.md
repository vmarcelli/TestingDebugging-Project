# Development Plan

The folders and files for this folder are as follows:

Files for the development plan, which documents how the project development will proceed, including team members, meetings, and roles, git workflow, and programming language, IDE, and style.
