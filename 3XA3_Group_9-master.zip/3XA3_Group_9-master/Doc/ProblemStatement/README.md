# Problem Statement

The folders and files for this folder are as follows:

Files documenting the problem that the project is attempting to solve, why it's a problem, and said problem's history.
