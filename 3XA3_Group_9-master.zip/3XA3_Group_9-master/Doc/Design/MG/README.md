# Module Guide

Files for the module guide, which documents, in natural language, the modules of the project, why they're needed and what their role is.
