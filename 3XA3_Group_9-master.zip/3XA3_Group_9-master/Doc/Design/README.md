# Design Documentation

The folders and files for this folder are as follows:

MG - Folder with the module guide, which documents, in natural language, the modules of the project, why they're needed and what their role is.
MIS - Folder with the module interface specification, which documents, in formal language, what their syntax and semantics are.
module_decomposition.txt - simple list of the modules.
