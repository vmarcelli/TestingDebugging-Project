# Module Interface Specification #

Files for the module interface specification, which documents, in formal language, what their syntax and semantics are.
