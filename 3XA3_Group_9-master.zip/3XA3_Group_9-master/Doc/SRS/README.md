# Software Requirements Specification

The folders and files for this folder are as follows:

Files for the software requirements specification, which documents the functional and nonfunctional requirements of the project, as well as the project drivers.
