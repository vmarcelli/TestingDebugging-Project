# Final Presentation

The folders and files for this folder are as follows:

Files used for the final presentation of the project, namely the powerpoint.
