# Ratava

Team Name: Makiam Group

Team Members: Aidan McPhelim, Alexie McDonald, Illya Pilipenko


This project is a reimplementation of PAGAN (Python Avatar Generator for Absolute Nerds), located at: https://github.com/daboth/pagan

The folders and files for this project are as follows:

Doc - Documentation for the project
ProjectSchedule - Gantt chart
src - Implementation
